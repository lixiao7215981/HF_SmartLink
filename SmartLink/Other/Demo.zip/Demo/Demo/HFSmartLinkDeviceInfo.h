//
//  HFSmartLinkDeviceInfo.h
//  SmartlinkLib
//
//  Created by wangmeng on 15/3/17.
//  Copyright (c) 2015年 HF. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HFSmartLinkDeviceInfo : NSObject
@property (nonatomic,strong) NSString * ip;
@property (nonatomic,strong) NSString * mac;
@end
